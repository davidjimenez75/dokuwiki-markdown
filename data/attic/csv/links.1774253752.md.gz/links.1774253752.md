# CSV - Modification to allow links on CSV files

- (_) Dokuwiki Links
- (_) External URLS
- (_) Obsidian Links


<csv file="csv:links.csv"></csv>
