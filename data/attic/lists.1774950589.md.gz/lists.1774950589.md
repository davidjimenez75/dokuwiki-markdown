# lists

- hyphen
- hyphen
+ plus (DONE)
+ plus (#DONE)
+ plus #DONE
- ideas--
- notes--
- issues--1
- issues--#1