# lists

- hyphen
- hyphen
+ plus (DONE)
+ plus (#DONE)
+ plus #DONE
- ideas--
- notes--