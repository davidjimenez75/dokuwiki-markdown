# MERMAID

{{indexmenu>MERMAID#1}}


**Links ⭐**

- Mermaid Plugin -- https://www.dokuwiki.org/plugin:mermaid