**[[:MERMAID|MERMAID:MINDMAP]]**



<mermaid>
mindmap
  root(([[:SDIRS|**SDIRS**]]))
    [[:Alarms|**Alarms**]]
    [[:Audiobooks|**Audiobooks**]]
      [[:audiobooks|audiobooks]]
      [[:audiolibros|audiolibros]]      
    [[:Books|**Books**]]
      [[:ebooks|ebooks]]
      [[:library|library]]
      [[:librarys|librarys]]      
      [[:press|press]]      
    [[:DCIM|**DCIM**]]
    [[:Documents|**Documents**]]
    [[:Download|**Download**]]
    [[:Movies|**Movies**]]
      [[:Videos|**Videos**]]
    [[:Music|**Music**]]
    [[:Notifications|**Notifications**]]
    [[:Pictures|**Pictures**]]
      [[:pictures--2026|pictures--2026]]
    [[:Podcasts|**Podcasts**]]
    [[:Recordings|**Recordings**]]
    [[:Ringtones|**Ringtones**]]
</mermaid>