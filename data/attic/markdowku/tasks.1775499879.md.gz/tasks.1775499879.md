# markdowku:tasks

Tasks emojis:

- [ ] Pending task                                                                                                                      
- [_] Pending task alt                                                                                                                  
- [x] Done task                                                                                                                         
- [>] In progress                                                                                                                       
- [-] Cancelled                                                                                                                         
- (x) Done task                                                                                                                       
- (>) In progress                                                                                                                       
- (-) Blocked                                                                                                                           
- (_) Pending   