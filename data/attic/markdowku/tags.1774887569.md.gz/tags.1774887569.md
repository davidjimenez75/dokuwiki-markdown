# Modified to allow links on UPPERCASE (#TAGS)

- (CSV)         = `(CSV)`         -> `([[:CSV]])`
- (#CSV)        = `(#CSV)`        -> `([[:CSV|#CSV]])`
- (CSV:TO-DO)   = `(CSV:TO-DO)`   -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV--TO-DO)  = `(CSV--TO-DO)`  -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV---TO-DO) = `(CSV---TO-DO)` -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV+TO-DO)   = `(CSV+TO-DO)`   -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV/TO-DO)   = `(CSV/TO-DO)`   -> `([[:CSV:TO-DO|CSV:TO-DO]])`

**Added support for #UPPERCASE-TAGS**

- #UPPERCASE
- #MARKDOWN
- #OBSIDIAIN
- #DOKUWIKI-MARKDOWN
- #TAGS_WITH_UNDERSCORES


Back to **[[:markdowku]]**