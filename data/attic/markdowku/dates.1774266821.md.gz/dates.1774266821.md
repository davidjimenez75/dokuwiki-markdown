# Modified to support link to dates between parens 

NOTE: Is preffixed by year

+ (2026-03-23)
+ (2026-03-23 11:24)
+ (2026-03-23--1124)
+ (2026-03-23--112401)
