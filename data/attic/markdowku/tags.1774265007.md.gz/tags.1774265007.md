# Modified to allow links on #TAGS

- (CSV)         -> `([[:CSV]])`
- (#CSV)        -> `([[:CSV|#CSV]])`
- (CSV:TO-DO)   -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV--TO-DO)  -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV+TO-DO)   -> `([[:CSV:TO-DO|CSV:TO-DO]])`
- (CSV/TO-DO)   -> `([[:CSV:TO-DO|CSV:TO-DO]])`