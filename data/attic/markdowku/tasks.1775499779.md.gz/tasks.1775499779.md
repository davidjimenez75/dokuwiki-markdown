# markdowku:tasks

- [x] Done task                                                                                                                         
- [ ] Pending task                                                                                                                      
- [_] Pending task alt                                                                                                                  
- [>] In progress                                                                                                                       
- [-] Cancelled                                                                                                                         
- (x) Done task                                                                                                                       
- (>) In progress                                                                                                                       
- (-) Blocked                                                                                                                           
- (_) Pending   