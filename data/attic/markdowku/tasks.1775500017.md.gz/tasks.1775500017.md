# markdowku:tasks


Not working on list

- [ ] Pending task
- [_] Pending task alt
- [x] Done task
- [>] In progress
- [-] Cancelled
- (x) Done task
- (>) In progress
- (-) Blocked
- (_) Pending



Working H3 tasks emojis:

### - [ ] Pending task
### - [_] Pending task alt
### - [x] Done task
### - [>] In progress
### - [-] Cancelled
### - (x) Done task
### - (>) In progress
### - (-) Blocked
### - (_) Pending

Working on CSV list

<csv>
status,task
- [ ],Pending task
- [_],Pending task alt
- [x],Done task
- [>],In progress
- [-],Cancelled
- (x),Done task
- (>),In progress
- (-),Blocked
- (_),Pending
</csv>