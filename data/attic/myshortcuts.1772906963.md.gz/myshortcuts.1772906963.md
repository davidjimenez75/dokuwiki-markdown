# Myshortcuts

Plugin to customize Dokuwiki with Ctrl+e to edit and Ctrl+s to save and allow 10 snippets with Ctrl+i

This plugin is a learning project and should not be used in production environments with internet access. It is initially designed for use only on secure intranet sites.


**Shortcuts**

- Ctrl + e = Edit
- Ctrl + s = Save
- Ctrl + 1-0 = User snippets


**Cleaning cache:**

- https://www.dokuwiki.org/devel:caching#purging_the_cache

To purge the editor toolbar (and other cached JavaScript) call

- https://your.domain.com/lib/exe/js.php?purge=true


**Links ⭐**

- Myshortcuts -- https://www.dokuwiki.org/plugin:myshortcuts


**Voice to text (dictation)**

Add voice dictation button to editor toolbar.

Adds a microphone button to the DokuWiki editor toolbar using the Web Speech API (Chrome/Edge/Safari). 

The button appears only in edit mode and only when the API is supported. Recognition is continuous, inserts final transcripts at cursor position, and includes a pulsing red animation while recording. 

Feature is togglable via plugin settings.

You must allow access to the microphone on the browser by https to see the icon on the editor toolbar.

- Chrome, Edge, Opera and Safari.




