---
title: HIDDEN--obsidian compatible metatags testing with Dokuwiki
tags:
  - dokuwiki
  - extensions
  - metatags
  - php
  - wiki
category: metatags
status: wip
updated: 2026-03-07
---
# Frontmatter

