---
tags: [auto-generated, tasks]
---

  **Auto-generated page** — do not edit manually.
  Last updated: 2026-03-30 16:01:19 | 12 result(s) | Patterns: `[_]`, `[ ]` | Scan time: 0.21s

# Pending Tasks

<csv>
file,content
[[conf/entities.local.conf]],"[_] 🔲"
[[myshortcuts/text-to-voice]],"- [_] Working on Opera - Windows 11"
[[myshortcuts/text-to-voice]],"- [_] Working on Safari - Mac"
[[obsidian/features]],"- [ ] Set up daily notes template"
[[obsidian/features]],"- [ ] Explore community plugins"
[[obsidian/features]],"- [ ] Configure graph view"
[[obsidian/to-do]],"### - [_] Bold italic with 3 asterisks"
[[obsidian/to-do]],"### - [_] 🧩 Callouts (Admonitions)"
[[obsidian/to-do]],"### - [_] 📅 YAML Front Matter"
[[wiki/markdown]],"- [_] Emojis could be added to: conf/entities.local.conf :bulb:"
[[wiki/markdown]],"* [ ] Validate Dokuwiki rendering"
[[wiki/markdown]],"* [ ] Fix unsupported features"
</csv>
