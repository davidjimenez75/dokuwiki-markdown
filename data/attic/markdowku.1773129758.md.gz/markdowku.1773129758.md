# Markdowku

Integrates Markdown into DokuWiki syntax.

- Markdowku Plugin – https://www.dokuwiki.org/plugin:markdowku

- https://github.com/Medieninformatik-Regensburg/dokuwiki-plugin-markdowku/