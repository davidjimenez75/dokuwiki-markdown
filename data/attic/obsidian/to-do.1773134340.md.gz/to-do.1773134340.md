# obsidian:to-do



### - [_] Bold italic with 3 asterisks

```
***bold italic***
```



