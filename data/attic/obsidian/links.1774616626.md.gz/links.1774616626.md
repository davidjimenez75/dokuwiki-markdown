# Obsidian:links


- [[..:to-do]] - Relative links




Back to [[obsidian]]

