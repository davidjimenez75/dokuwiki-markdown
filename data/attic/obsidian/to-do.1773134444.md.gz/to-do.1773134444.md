# Obsidian:to-do


----
### - [_] Bold italic with 3 asterisks

```
***bold italic***
```





----
### - [_] 📅 YAML Front Matter


```yaml
---
title: Obsidian Features Demo
date: 2024-03-10
tags:
  - obsidian
  - markdown
  - productivity
author: Claude
status: complete
aliases:
  - Obsidian Demo
  - Markdown Features
---
```

