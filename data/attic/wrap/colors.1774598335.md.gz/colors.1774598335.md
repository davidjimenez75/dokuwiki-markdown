#  Wrap:Colors


**<wrap orange>MODIFIED VERSION</wrap> TO ALLOW HIGHLIGH TEXT ON MULTIPLE COLORS:**

- Highlighted on color <wrap red>red</wrap>
- Highlighted on color <wrap orange>orange</wrap>
- Highlighted on color <wrap yellow>yellow</wrap>
- Highlighted on color <wrap blue>blue</wrap>
- Highlighted on color <wrap green>green</wrap>
- Highlighted on color <wrap purple>purple</wrap>
- Highlighted on color <wrap brown>brown</wrap>
- Highlighted on color <wrap white>white</wrap>
- Highlighted on color <wrap black>black</wrap>

**COLOR EMOJIS:**

- FILE=`conf\entities.local.conf`

(red)(orange)(yellow)(blue)(green)(purple)(brown)(white)(black)

```
(red)     🟥
(orange)  🟧
(yellow)  🟨
(blue)    🟦
(green)   🟩
(purple)  🟪
(brown)   🟫
(white)   ⬜
(black)   ⬛
```


---------------------------------------------------------------------------------------------------------
**DEMOS**

- <wrap :en>`<wrap :en>`This text is explicitly marked as English`</wrap>`</wrap>

- <wrap :es>`<wrap :es>`This text is explicitly marked as Spanish áéíóú -  Ejemplo: camion sin tilde`</wrap>`</wrap>


**wrap status**

- <wrap danger>danger</wrap>
- <wrap warning>warning</wrap>
- <wrap caution>caution</wrap>
- <wrap notice>notice</wrap>
- <wrap safety>safety</wrap>


**wrap lowercase**

- <wrap info> info</wrap>
- <wrap tip> tip</wrap>
- <wrap important> important</wrap>
- <wrap alert> alert</wrap>
- <wrap help> help</wrap>
- <wrap download> download</wrap>
- <wrap todo> todo</wrap>



**WRAP UPPERCASE**

<WRAP info> info</WRAP>

<WRAP tip> tip</WRAP>

<WRAP important> important</WRAP>

<WRAP alert> alert</WRAP>

<WRAP help> help</WRAP>

<WRAP download> download</WRAP>

<WRAP todo> todo</WRAP>







Back to **[[wrap]]**