# Myshortcuts

Plugin to customize Dokuwiki with Ctrl+e to edit and Ctrl+s to save and allow 10 snippets with Ctrl+i

This plugin is a learning project and should not be used in production environments with internet access. It is initially designed for use only on secure intranet sites.


## Features

- Ctrl + e = Edit
- Ctrl + s = Save
- Ctrl + 1-0 = User snippets



**Cleaning cache:**

- https://www.dokuwiki.org/devel:caching#purging_the_cache

To purge the editor toolbar (and other cached JavaScript) call

- https://wiki.mpc.cc/lib/exe/js.php?purge=true



**Links ⭐**

- Myshortcuts -- https://www.dokuwiki.org/plugin:myshortcuts

