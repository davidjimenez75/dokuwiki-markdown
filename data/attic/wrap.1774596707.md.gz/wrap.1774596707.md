# Wrap




**COLORS:**

- <wrap red>red</wrap>
- <wrap orange>orange</wrap>
- <wrap yellow>yellow</wrap>
- <wrap blue>blue</wrap>
- <wrap green>green</wrap>
- <wrap purple>purple</wrap>
- <wrap brown>brown</wrap>
- <wrap white>white</wrap>
- <wrap black>black</wrap>

**EMOJIS:**

```
[red]     🟥
[orange]  🟧
[yellow]  🟨
[blue]    🟦
[green]   🟩
[purple]  🟪
[brown]   🟫
[white]   ⬜
[black]   ⬛
```