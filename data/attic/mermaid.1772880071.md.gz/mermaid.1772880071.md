# MERMAID

{{indexmenu>MERMAID#1}}


**Links ⭐**

https://www.dokuwiki.org/plugin:mermaid