# Wrap



- Wrap Plugin - https://www.dokuwiki.org/plugin:wrap


**COLORS:**

- <wrap red>red</wrap>
- <wrap orange>orange</wrap>
- <wrap yellow>yellow</wrap>
- <wrap blue>blue</wrap>
- <wrap green>green</wrap>
- <wrap purple>purple</wrap>
- <wrap brown>brown</wrap>
- <wrap white>white</wrap>
- <wrap black>black</wrap>

**EMOJIS:**

```
[red]     🟥
[orange]  🟧
[yellow]  🟨
[blue]    🟦
[green]   🟩
[purple]  🟪
[brown]   🟫
[white]   ⬜
[black]   ⬛
```


---------------------------------------------------------------------------------------------------------
## DEMOS

<wrap :en>This text is explicitly marked as English.</wrap>

<wrap :es>This text is explicitly marked as Spanish áéíóú -  camion sin tilde.</wrap>


### wrap status

<wrap danger>danger</wrap>
<wrap warning>warning</wrap>
<wrap caution>caution</wrap>
<wrap notice>notice</wrap>
<wrap safety>safety</wrap>


### wrap en minusculas

<wrap info> info</wrap>
<wrap tip> tip</wrap>
<wrap important> important</wrap>
<wrap alert> alert</wrap>
<wrap help> help</wrap>
<wrap download> download</wrap>
<wrap todo> todo</wrap>



### WRAP EN MAYUSCULAS

<WRAP info> info</WRAP>

<WRAP tip> tip</WRAP>

<WRAP important> important</WRAP>

<WRAP alert> alert</WRAP>

<WRAP help> help</WRAP>

<WRAP download> download</WRAP>

<WRAP todo> todo</WRAP>



